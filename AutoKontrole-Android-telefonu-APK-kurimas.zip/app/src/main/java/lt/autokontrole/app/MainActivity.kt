package lt.autokontrole.app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.work.*
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.util.concurrent.TimeUnit

data class Vehicle(
    val id: String,
    val plate: String,
    val make: String,
    val model: String,
    val year: String,
    val vin: String,
    val expiry: String,
    val history: List<String> = emptyList()
)

class MainActivity : ComponentActivity() {
    private val requestPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel(this)
        scheduleDailyReminder(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent { AutoKontroleApp(this) }
    }
}

private const val PREFS = "autokontrole_local"
private const val KEY_CARS = "vehicles"

fun loadVehicles(context: Context): List<Vehicle> {
    val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_CARS, "[]") ?: "[]"
    return runCatching {
        val arr = JSONArray(raw)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val h = o.optJSONArray("history") ?: JSONArray()
            Vehicle(
                id = o.optString("id"), plate = o.optString("plate"),
                make = o.optString("make"), model = o.optString("model"),
                year = o.optString("year"), vin = o.optString("vin"),
                expiry = o.optString("expiry"),
                history = (0 until h.length()).map { h.optString(it) }
            )
        }
    }.getOrDefault(emptyList())
}

fun saveVehicles(context: Context, vehicles: List<Vehicle>) {
    val arr = JSONArray()
    vehicles.forEach { v ->
        val h = JSONArray()
        v.history.forEach { h.put(it) }
        arr.put(JSONObject().apply {
            put("id", v.id); put("plate", v.plate); put("make", v.make)
            put("model", v.model); put("year", v.year); put("vin", v.vin)
            put("expiry", v.expiry); put("history", h)
        })
    }
    context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_CARS, arr.toString()).apply()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AutoKontroleApp(context: Context) {
    var vehicles by remember { mutableStateOf(loadVehicles(context)) }
    var showAdd by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<Vehicle?>(null) }
    var search by remember { mutableStateOf("") }

    fun update(list: List<Vehicle>) {
        vehicles = list
        saveVehicles(context, list)
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF145C48))) {
        Scaffold(
            topBar = { TopAppBar(title = { Text("AutoKontrolė", fontWeight = FontWeight.Bold) }) },
            floatingActionButton = {
                FloatingActionButton(onClick = { showAdd = true }) {
                    Icon(Icons.Default.Add, contentDescription = "Pridėti automobilį")
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SummaryCard("Visi", vehicles.size.toString(), Modifier.weight(1f))
                    SummaryCard("Artėja", vehicles.count { daysLeft(it.expiry) in 0..30 }.toString(), Modifier.weight(1f))
                    SummaryCard("Pasibaigė", vehicles.count { daysLeft(it.expiry) < 0 }.toString(), Modifier.weight(1f))
                }
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = search, onValueChange = { search = it },
                    modifier = Modifier.fillMaxWidth(), label = { Text("Ieškoti pagal numerį, markę ar modelį") },
                    singleLine = true
                )
                Spacer(Modifier.height(12.dp))
                Text("Automobilių parkas", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                val filtered = vehicles.filter {
                    listOf(it.plate, it.make, it.model).any { s -> s.contains(search, ignoreCase = true) }
                }
                if (filtered.isEmpty()) {
                    Text(if (vehicles.isEmpty()) "Automobilių dar nėra. Paspauskite + ir pridėkite pirmą automobilį." else "Pagal paiešką automobilių nerasta.")
                }
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(filtered, key = { it.id }) { car ->
                        VehicleCard(car, onInspection = { selected = car }, onDelete = {
                            update(vehicles.filterNot { v -> v.id == car.id })
                        })
                    }
                }
            }
        }
    }

    if (showAdd) AddVehicleDialog(
        onDismiss = { showAdd = false },
        onSave = { car -> update(vehicles + car); showAdd = false }
    )
    selected?.let { car ->
        InspectionDialog(car, onDismiss = { selected = null }) { expiry ->
            val today = LocalDate.now().toString()
            val updated = car.copy(expiry = expiry, history = car.history + "$today → $expiry")
            update(vehicles.map { if (it.id == car.id) updated else it })
            selected = null
        }
    }
}

@Composable
fun SummaryCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier) {
        Column(Modifier.padding(12.dp)) {
            Text(value, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text(label, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
fun VehicleCard(car: Vehicle, onInspection: () -> Unit, onDelete: () -> Unit) {
    val days = daysLeft(car.expiry)
    val status = when {
        car.expiry.isBlank() -> "TA data nenurodyta"
        days < 0 -> "TA pasibaigusi"
        days <= 30 -> "Baigiasi po $days d."
        else -> "Galioja iki ${car.expiry}"
    }
    val color = when {
        days < 0 -> MaterialTheme.colorScheme.error
        days <= 30 -> androidx.compose.ui.graphics.Color(0xFFB56A00)
        else -> androidx.compose.ui.graphics.Color(0xFF16734A)
    }
    Card {
        Column(Modifier.fillMaxWidth().padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.DirectionsCar, contentDescription = null)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("${car.make} ${car.model}", fontWeight = FontWeight.Bold)
                    Text("${car.plate} • ${car.year}", style = MaterialTheme.typography.bodySmall)
                }
                Text(status, color = color, style = MaterialTheme.typography.labelMedium)
            }
            if (car.vin.isNotBlank()) Text("VIN: ${car.vin}", style = MaterialTheme.typography.bodySmall)
            if (car.history.isNotEmpty()) Text("TA istorija: ${car.history.size} įraš.", style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onInspection, modifier = Modifier.weight(1f)) { Text("Registruoti TA") }
                OutlinedButton(onClick = onDelete) { Text("Ištrinti") }
            }
        }
    }
}

@Composable
fun AddVehicleDialog(onDismiss: () -> Unit, onSave: (Vehicle) -> Unit) {
    var plate by remember { mutableStateOf("") }
    var make by remember { mutableStateOf("") }
    var model by remember { mutableStateOf("") }
    var year by remember { mutableStateOf("") }
    var vin by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Pridėti automobilį") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(plate, { plate = it.uppercase() }, label = { Text("Valstybinis numeris *") }, singleLine = true)
                OutlinedTextField(make, { make = it }, label = { Text("Markė *") }, singleLine = true)
                OutlinedTextField(model, { model = it }, label = { Text("Modelis") }, singleLine = true)
                OutlinedTextField(year, { year = it }, label = { Text("Pagaminimo metai") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                OutlinedTextField(vin, { vin = it.uppercase() }, label = { Text("VIN numeris") }, singleLine = true)
            }
        },
        confirmButton = {
            TextButton(enabled = plate.isNotBlank() && make.isNotBlank(), onClick = {
                onSave(Vehicle(java.util.UUID.randomUUID().toString(), plate.trim(), make.trim(), model.trim(), year.trim(), vin.trim(), ""))
            }) { Text("Išsaugoti") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Atšaukti") } }
    )
}

@Composable
fun InspectionDialog(car: Vehicle, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var mode by remember { mutableStateOf("years") }
    var years by remember { mutableStateOf("1") }
    var date by remember { mutableStateOf(LocalDate.now().plusYears(1).toString()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("TA registravimas – ${car.plate}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Pasirinkite galiojimo nustatymo būdą.")
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(mode == "years", { mode = "years" }); Text("Laikotarpis")
                    Spacer(Modifier.width(8.dp))
                    RadioButton(mode == "date", { mode = "date" }); Text("Tiksli data")
                }
                if (mode == "years") {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(years == "1", { years = "1" }); Text("1 metai")
                        Spacer(Modifier.width(12.dp))
                        RadioButton(years == "2", { years = "2" }); Text("2 metai")
                    }
                    Text("Galios iki: ${LocalDate.now().plusYears(years.toLong())}")
                } else {
                    OutlinedTextField(date, { date = it }, label = { Text("Galiojimo data (YYYY-MM-DD)") }, singleLine = true)
                    Text("Pavyzdys: 2027-11-09")
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val expiry = if (mode == "years") LocalDate.now().plusYears(years.toLong()).toString() else date
                runCatching { LocalDate.parse(expiry) }.onSuccess { onSave(expiry) }
            }) { Text("Išsaugoti TA") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Atšaukti") } }
    )
}

fun daysLeft(date: String): Long {
    if (date.isBlank()) return Long.MAX_VALUE
    return runCatching { ChronoUnit.DAYS.between(LocalDate.now(), LocalDate.parse(date)) }.getOrDefault(Long.MAX_VALUE)
}

fun createNotificationChannel(context: Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        val channel = NotificationChannel("ta_reminders", "TA priminimai", NotificationManager.IMPORTANCE_DEFAULT)
        context.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }
}

class ReminderWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        val cars = loadVehicles(applicationContext)
        val due = cars.filter { daysLeft(it.expiry) in 0..30 }
        val expired = cars.filter { daysLeft(it.expiry) < 0 }
        val count = due.size + expired.size
        if (count > 0 && (Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED)) {
            val message = buildString {
                if (due.isNotEmpty()) append("Per 30 dienų TA baigiasi: ${due.joinToString { it.plate }}. ")
                if (expired.isNotEmpty()) append("TA pasibaigusi: ${expired.joinToString { it.plate }}.")
            }
            val notification = NotificationCompat.Builder(applicationContext, "ta_reminders")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("AutoKontrolė – TA priminimas")
                .setContentText(message)
                .setStyle(NotificationCompat.BigTextStyle().bigText(message))
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true).build()
            val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.notify(1001, notification)
        }
        return Result.success()
    }
}

fun scheduleDailyReminder(context: Context) {
    val request = PeriodicWorkRequestBuilder<ReminderWorker>(24, TimeUnit.HOURS).build()
    WorkManager.getInstance(context).enqueueUniquePeriodicWork(
        "daily_ta_reminder", ExistingPeriodicWorkPolicy.UPDATE, request
    )
}
