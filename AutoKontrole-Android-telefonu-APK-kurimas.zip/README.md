# AutoKontrolė – vieno naudotojo Android versija

Ši versija skirta vienam žmogui ir vienam Android įrenginiui. Nėra darbuotojų paskyrų, prisijungimo ar bendros internetinės duomenų bazės.

## Funkcijos
- Automobilių pridėjimas: numeris, markė, modelis, metai, VIN.
- TA registravimas: 1 metai, 2 metai arba tiksli galiojimo pabaigos data.
- TA galiojimo būsenos: galioja, baigiasi per 30 dienų, pasibaigusi.
- TA įrašų istorijos skaičiavimas ir rodymas.
- Vietinis duomenų saugojimas telefone.
- Kasdienis fono patikrinimas ir pranešimas apie artėjančią (per 30 d.) arba pasibaigusią TA.

## Paleidimas
1. Atverkite katalogą Android Studio.
2. Palaukite, kol Gradle sinchronizacija baigsis.
3. Prijunkite Android telefoną arba paleiskite emuliatorių.
4. Spauskite Run.

## Svarbu
- Duomenys saugomi tik šiame telefone. Pašalinus programėlę arba išvalius jos duomenis, jie gali būti prarasti. Prieš realų naudojimą rekomenduojama pridėti eksportą / atsarginę kopiją.
- Android 13 ir naujesnėje versijoje reikia leisti pranešimus.
- Fono priminimai vykdomi apytiksliai kas 24 valandas; Android gali atidėti vykdymą dėl baterijos optimizavimo.
- „1 arba 2 metai“ yra patogus skaičiavimo pasirinkimas, bet tikrą TA galiojimo pabaigos datą reikia patikrinti TA dokumente. Patikimiausia įvesti oficialią datą.

## APK kūrimas tik telefonu (GitHub Actions)
Šiame projekte yra `.github/workflows/build-apk.yml` failas. Įkėlus visą projekto turinį į GitHub saugyklą, atverkite **Actions** → **Build AutoKontrole APK** → **Run workflow**. Kai veiksmas baigsis žalia varnele, atverkite vykdymą ir atsisiųskite `AutoKontrole-debug-apk` iš **Artifacts**. Išarchyvuokite ZIP ir telefone atidarykite `app-debug.apk`.
Debug APK yra bandomasis diegimo paketas, ne Play Store leidimas. Įdiekite tik savo sukurtą ir patikrintą paketą.
