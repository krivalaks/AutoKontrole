package lt.autokontrole.app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.media.RingtoneManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.work.*
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.util.concurrent.TimeUnit

data class Vehicle(
    val id: String,
    val plate: String,
    val make: String,
    val model: String,
    val year: String,
    val vin: String,
    val expiry: String,
    val history: List<String> = emptyList(),
    val details: String = "",
    val category: String = "",
    val tachographExpiry: String = ""
)

class MainActivity : ComponentActivity() {
    private val requestPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel(this)
        scheduleDailyReminder(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent { AutoKontroleApp(this) }
    }
}

private const val PREFS = "autokontrole_local"
private const val KEY_CARS = "vehicles"
private const val KEY_REMIND_15 = "remind_15_days"
private const val KEY_REMIND_7 = "remind_7_days"
private const val KEY_SENT_REMINDERS = "sent_ta_reminders"
private const val KEY_FLEET_IMPORTED = "pdf_fleet_imported_2026_06"

fun loadVehicles(context: Context): List<Vehicle> {
    val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_CARS, "[]") ?: "[]"
    return runCatching {
        val arr = JSONArray(raw)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val h = o.optJSONArray("history") ?: JSONArray()
            Vehicle(
                id = o.optString("id"), plate = o.optString("plate"),
                make = o.optString("make"), model = o.optString("model"),
                year = o.optString("year"), vin = o.optString("vin"),
                expiry = o.optString("expiry"),
                history = (0 until h.length()).map { h.optString(it) },
                details = o.optString("details"), category = normalizeCategory(o.optString("category")), tachographExpiry = o.optString("tachographExpiry")
            )
        }
    }.getOrDefault(emptyList())
}

// Transporto priemonės iš naudotojo pateikto 2026-06 sąrašo. TA datos PDF faile nenurodytos.
fun importInitialFleet(context: Context, current: List<Vehicle>): List<Vehicle> {
    val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    if (prefs.getBoolean(KEY_FLEET_IMPORTED, false)) return current
    val fleet = listOf(
        Vehicle("pdf-JZ864", "JZ864", "ANDOVER", "", "", "SA963041U60850018", "", details="SDK HETCPEFE • Spalva MĖLYNA • Dok. Y755337 • Registruota 2022-01-12 • Pastaba: Tralas priekaba", category="Sunkusis transportas / priekaba"),
        Vehicle("pdf-JZM031", "JZM031", "DAF", "CF 75", "2004", "XLRAE75PC0E647091", "", details="SDK NNKFHMRA • Spalva ŽALIA • Dok. H358552 • Registruota 2017-09-26 • EURO III • Pastaba: DAF Fiskaras", category="Sunkusis transportas"),
        Vehicle("pdf-HM293", "HM293", "DESOT", "SD3ANS", "2008", "YE7SD3AAHM8205295", "", details="SDK KATAEEKC • Spalva PILKA • Dok. H223787 • Registruota 2017-05-25 • EURO IV • Pastaba: Žvyrinė apvali Ruliaus", category="Sunkusis transportas / priekaba"),
        Vehicle("pdf-JZ345", "JZ345", "FELDBINDER", "EUT 36.3", "", "W09334B2FX2F07255", "", details="SDK HERHCAFH • Spalva BALTA • Dok. I762544 • Registruota 2020-04-07 • Pastaba: Cementovežio priekaba", category="Sunkusis transportas / priekaba"),
        Vehicle("pdf-GFV262", "GFV262", "IVECO", "ML 80 E", "2001", "ZCFA80C0102352318", "", details="SDK NRMETEKM • Spalva BALTA • Dok. H358882 • Registruota 2013-02-06 • EURO II • Pastaba: Iveco Vaido", category="Sunkusis transportas"),
        Vehicle("pdf-JI067", "JI067", "KRONE", "", "2016", "WKEAZ000000714785", "", details="SDK CKNRPETT • Spalva PILKA • Dok. K0380240 • Registruota 2025-01-23 • EURO VI • Pastaba: Vaciaus priekaba", category="Sunkusis transportas / priekaba"),
        Vehicle("pdf-AZU189", "AZU189", "SCANIA", "R 124 CB", "1998", "XLEP8X40004387030", "", details="Spalva ORANŽINĖ • Dok. K0812132 • Registruota 2026-02-17 • EURO II • Pastaba: Betonvežė 8m3 Oranžinė", category="Sunkusis transportas"),
        Vehicle("pdf-MEO895", "MEO895", "SCANIA", "R 124 CB", "2000", "XLER8X40004435069", "", details="SDK MNREKTMM • Spalva BALTA • Dok. Y875206 • Registruota 2022-03-25 • EURO II • Pastaba: Betonvežė 8m3 Balta", category="Sunkusis transportas"),
        Vehicle("pdf-JFO682", "JFO682", "SCANIA", "R 420 LA4X2MNA", "2006", "VLUR4X20009111277", "", details="SDK AMKRMFPM • Spalva BALTA • Dok. F731465 • Registruota 2016-07-26 • EURO III • Pastaba: Baltasis Vilkikas", category="Sunkusis transportas"),
        Vehicle("pdf-JPU341", "JPU341", "SCANIA", "R 420 LA4X2MNA", "2008", "VLUR4X20009134489", "", details="SDK NAMMHHFA • Spalva ORANŽINĖ • Dok. H223706 • Registruota 2017-05-23 • EURO IV • Pastaba: Ruliaus Vilkikas Oranžinė", category="Sunkusis transportas"),
        Vehicle("pdf-NC997", "NC997", "SCHMITZ", "S01", "2012", "WSM00000003165451", "", details="SDK RPCHNAME • Spalva PILKA • Dok. I661819 • Registruota 2019-11-20 • EURO V • Pastaba: Fūros priekaba", category="Sunkusis transportas / priekaba"),
        Vehicle("pdf-GU837", "GU837", "SCHMITZ GOTHA", "SKI 24", "2005", "WSK00000001210283", "", details="SDK KRHEKPNM • Spalva PILKA • Dok. H358971 • Registruota 2017-10-10 • EURO III • Pastaba: Žvyrinė kvadratinė", category="Sunkusis transportas / priekaba"),
        Vehicle("pdf-HOF126", "HOF126", "VOLVO", "FM12", "2002", "YV2J4CLC42A552846", "", details="SDK RRTAAMCK • Spalva MĖLYNA • Dok. F581152 • Registruota 2015-03-10 • EURO III • Pastaba: Vaciaus Fiskaras", category="Sunkusis transportas"),
        Vehicle("pdf-MZV892", "MZV892", "VOLVO", "FM 400", "2006", "YV2JSG0G26A615940", "", details="SDK MARTRAKC • Spalva GELTONA • Dok. J821461 • Registruota 2024-03-14 • EURO III • Pastaba: Betonvežė 8m3 Bitute", category="Sunkusis transportas"),
        Vehicle("pdf-ON478", "ON478", "FARO", "MAGICUS", "2021", "SVNFA800A00002192", "", details="SDK PREMKRRK • Spalva PILKA • Dok. K0088899 • Registruota 2021-06-16 • EURO VI • Pastaba: 3.0m lengvoji priekabėlė", category="Lengvoji priekaba"),
        Vehicle("pdf-MT172", "MT172", "Priekaba", "2.5 m", "", "", "", details="Pastaba: 2.5m lengvoji priekabėlė", category="Lengvoji priekaba"),
        Vehicle("pdf-OT456", "OT456", "TAVA", "Tava-250", "2021", "", "", details="Dok. J441237 • Registruota 2023-06-08 • Pastaba: 2.5m lengvoji priekabėlė", category="Lengvoji priekaba"),
        Vehicle("pdf-KUG101", "KUG101", "AUDI", "Q5", "2013", "WAUZZZ8R3DA092951", "", details="SDK EFNMMCEM • Spalva PILKA • Dok. I157438 • Registruota 2019-01-16 • EURO V", category="Lengvasis automobilis"),
        Vehicle("pdf-JZU101", "JZU101", "VOLKSWAGEN", "MULTIVAN", "2017", "WV2ZZZ7HZJH022030", "", details="SDK CHEHCPKC • Spalva RUDA • Dok. H360972 • Registruota 2017-08-02 • EURO VI", category="Lengvasis automobilis"),
        Vehicle("pdf-CGU101", "CGU101", "VOLKSWAGEN", "SHARAN", "2005", "WVWZZZ7MZ6V001781", "", details="SDK TRRMNKCC • Spalva PILKA • Dok. I150281 • Registruota 2018-12-13 • EURO III", category="Lengvasis automobilis"),
        Vehicle("pdf-EB0101", "EB0101", "VOLVO", "XC90", "2020", "YV1LFBMUDM1698575", "", details="SDK TRMRAKHP • Spalva RUDA • Dok. J821963 • Registruota 2022-11-08 • EURO VI", category="Lengvasis automobilis"),
        Vehicle("pdf-BHL101", "BHL101", "VW", "TRANSPORTER", "2004", "WV2ZZZ7HZ4X023012", "", details="SDK FETFEATN • Spalva PILKA • Dok. A628356 • Registruota 2006-03-14 • EURO III", category="Lengvasis automobilis"),
        Vehicle("pdf-KSK851", "KSK851", "VW", "CADDY", "2006", "WV2ZZZ2KZ6X093374", "", details="SDK FECTTCRT • Spalva BALTA • Dok. I150279 • Registruota 2012-05-11 • EURO III", category="Lengvasis automobilis"),
        Vehicle("pdf-FCH101", "FCH101", "VW", "PASSAT", "2007", "WVWZZZ3CZ6P167268", "", details="SDK HENFEKRH • Spalva JUODA • Dok. C883984 • Registruota 2010-07-14 • EURO IV", category="Lengvasis automobilis"),
        Vehicle("pdf-CRR101", "CRR101", "VW", "SHARAN", "2009", "WVWZZZ7MZAV010243", "", details="SDK TARKPTTT • Spalva JUODA • Dok. H931302 • Registruota 2018-08-17 • EURO IV", category="Lengvasis automobilis"),
        Vehicle("pdf-KBR101", "KBR101", "VW", "PASSAT", "2010", "WVWZZZ3CZAE193042", "", details="SDK KAHTRHAP • Spalva JUODA • Dok. K0380363 • Registruota 2025-01-29 • EURO V", category="Lengvasis automobilis"),
        Vehicle("pdf-NCP101", "NCP101", "VW", "SHARAN", "2011", "WVWZZZ7NZCV008872", "", details="SDK TKCEEREP • Spalva JUODA • Dok. K0058951 • Registruota 2024-08-20 • EURO V", category="Lengvasis automobilis")
    )
    val existingPlates = current.map { it.plate.uppercase() }.toSet()
    val normalizedCurrent = current.map { it.copy(category = normalizeCategory(it.category)) }
    val merged = normalizedCurrent + fleet.filterNot { it.plate.uppercase() in existingPlates }
    saveVehicles(context, merged)
    prefs.edit().putBoolean(KEY_FLEET_IMPORTED, true).apply()
    return merged
}

fun normalizeCategory(value: String): String {
    val v = value.lowercase()
    return when {
        v.contains("priekab") -> "Priekabos"
        v.contains("lengvasis") -> "Lengvieji automobiliai"
        v.contains("sunkusis") -> "Sunkusis transportas"
        else -> "Lengvieji automobiliai"
    }
}

fun saveVehicles(context: Context, vehicles: List<Vehicle>) {
    val arr = JSONArray()
    vehicles.forEach { v ->
        val h = JSONArray()
        v.history.forEach { h.put(it) }
        arr.put(JSONObject().apply {
            put("id", v.id); put("plate", v.plate); put("make", v.make)
            put("model", v.model); put("year", v.year); put("vin", v.vin)
            put("expiry", v.expiry); put("history", h); put("details", v.details); put("category", normalizeCategory(v.category)); put("tachographExpiry", v.tachographExpiry)
        })
    }
    context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_CARS, arr.toString()).apply()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AutoKontroleApp(context: Context) {
    var vehicles by remember { mutableStateOf(importInitialFleet(context, loadVehicles(context))) }
    var showAdd by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<Vehicle?>(null) }
    var search by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf("VISI") }
    var selectedCategory by remember { mutableStateOf("VISOS KATEGORIJOS") }
    var tachographSelected by remember { mutableStateOf<Vehicle?>(null) }
    var showReminderSettings by remember { mutableStateOf(false) }
    val prefs = remember { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE) }
    var remind15 by remember { mutableStateOf(prefs.getBoolean(KEY_REMIND_15, true)) }
    var remind7 by remember { mutableStateOf(prefs.getBoolean(KEY_REMIND_7, true)) }

    fun update(list: List<Vehicle>) {
        vehicles = list
        saveVehicles(context, list)
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF145C48))) {
        Scaffold(
            topBar = { TopAppBar(
                title = { Text("AutoKontrolė", fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton(onClick = { showReminderSettings = true }) {
                        Icon(Icons.Default.Notifications, contentDescription = "Priminimų nustatymai")
                    }
                }
            ) },
            floatingActionButton = {
                FloatingActionButton(onClick = { showAdd = true }) {
                    Icon(Icons.Default.Add, contentDescription = "Pridėti automobilį")
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SummaryCard("Visi", vehicles.size.toString(), Modifier.weight(1f))
                    SummaryCard("Artėja", vehicles.count { daysLeft(it.expiry) in 0..30 }.toString(), Modifier.weight(1f))
                    SummaryCard("Pasibaigė", vehicles.count { daysLeft(it.expiry) < 0 }.toString(), Modifier.weight(1f))
                }
                Spacer(Modifier.height(12.dp))
                Text("Rodyti automobilius", style = MaterialTheme.typography.labelLarge)
                Spacer(Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    FilterChip(
                        selected = selectedFilter == "VISI",
                        onClick = { selectedFilter = "VISI" },
                        label = { Text("VISI") }
                    )
                    FilterChip(
                        selected = selectedFilter == "ARTEJA",
                        onClick = { selectedFilter = "ARTEJA" },
                        label = { Text("ARTĖJA") }
                    )
                    FilterChip(
                        selected = selectedFilter == "PASIBAIGE",
                        onClick = { selectedFilter = "PASIBAIGE" },
                        label = { Text("PASIBAIGĖ") }
                    )
                }
                Spacer(Modifier.height(10.dp))
                Text("Kategorija", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
                    listOf("VISOS KATEGORIJOS", "Lengvieji automobiliai", "Priekabos", "Sunkusis transportas").forEach { category ->
                        FilterChip(selected = selectedCategory == category, onClick = { selectedCategory = category }, label = {
                            Text(when(category) { "VISOS KATEGORIJOS" -> "VISOS"; "Lengvieji automobiliai" -> "LENGVIEJI"; "Priekabos" -> "PRIEKABOS"; else -> "SUNKUSIS" })
                        })
                    }
                }
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = search, onValueChange = { search = it },
                    modifier = Modifier.fillMaxWidth(), label = { Text("Ieškoti pagal numerį, markę ar modelį") },
                    singleLine = true
                )
                Spacer(Modifier.height(12.dp))
                Text("Automobilių parkas", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                val filtered = vehicles.filter { car ->
                    val matchesSearch = listOf(car.plate, car.make, car.model, car.vin)
                        .any { value -> value.contains(search, ignoreCase = true) }
                    val days = daysLeft(car.expiry)
                    val matchesFilter = when (selectedFilter) {
                        "ARTEJA" -> days in 0..30
                        "PASIBAIGE" -> days < 0
                        else -> true
                    }
                    val matchesCategory = selectedCategory == "VISOS KATEGORIJOS" || normalizeCategory(car.category) == selectedCategory
                    matchesSearch && matchesFilter && matchesCategory
                }
                if (filtered.isEmpty()) {
                    val emptyMessage = when {
                        vehicles.isEmpty() -> "Automobilių dar nėra. Paspauskite + ir pridėkite pirmą automobilį."
                        selectedFilter == "ARTEJA" -> "Artėjančių techninių apžiūrų nėra."
                        selectedFilter == "PASIBAIGE" -> "Pasibaigusių techninių apžiūrų nėra."
                        search.isNotBlank() -> "Pagal paiešką automobilių nerasta."
                        else -> "Automobilių nėra."
                    }
                    Text(emptyMessage)
                }
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(filtered, key = { it.id }) { car ->
                        VehicleCard(car, onInspection = { selected = car }, onTachograph = { tachographSelected = car }, onDelete = {
                            update(vehicles.filterNot { v -> v.id == car.id })
                        })
                    }
                }
            }
        }
    }

    if (showReminderSettings) ReminderSettingsDialog(
        remind15 = remind15,
        remind7 = remind7,
        onRemind15Change = { remind15 = it; prefs.edit().putBoolean(KEY_REMIND_15, it).apply() },
        onRemind7Change = { remind7 = it; prefs.edit().putBoolean(KEY_REMIND_7, it).apply() },
        onDismiss = { showReminderSettings = false }
    )

    if (showAdd) AddVehicleDialog(
        onDismiss = { showAdd = false },
        onSave = { car -> update(vehicles + car); showAdd = false }
    )
    tachographSelected?.let { car ->
        TachographDialog(car, onDismiss = { tachographSelected = null }) { expiry ->
            val updated = car.copy(tachographExpiry = expiry)
            update(vehicles.map { if (it.id == car.id) updated else it })
            tachographSelected = null
        }
    }
    selected?.let { car ->
        InspectionDialog(car, onDismiss = { selected = null }) { expiry ->
            val today = LocalDate.now().toString()
            val updated = car.copy(expiry = expiry, history = car.history + "$today → $expiry")
            update(vehicles.map { if (it.id == car.id) updated else it })
            selected = null
        }
    }
}

@Composable
fun ReminderSettingsDialog(
    remind15: Boolean,
    remind7: Boolean,
    onRemind15Change: (Boolean) -> Unit,
    onRemind7Change: (Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("TA priminimų nustatymai") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Telefonas primins apie techninės apžiūros pabaigą. Pranešimai siunčiami su telefono pranešimų kanalo garsu.")
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = remind15, onCheckedChange = onRemind15Change)
                    Text("Priminimas prieš 15 dienų")
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = remind7, onCheckedChange = onRemind7Change)
                    Text("Priminimas prieš 7 dienas")
                }
                Text("Pastaba: Android nustatymuose turi būti leidžiami AutoKontrolė pranešimai ir jų garsas.", style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Išsaugoti") } }
    )
}

@Composable
fun SummaryCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier) {
        Column(Modifier.padding(12.dp)) {
            Text(value, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text(label, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
fun VehicleCard(car: Vehicle, onInspection: () -> Unit, onTachograph: () -> Unit, onDelete: () -> Unit) {
    val days = daysLeft(car.expiry)
    val status = when {
        car.expiry.isBlank() -> "TA data nenurodyta"
        days < 0 -> "TA pasibaigusi"
        days <= 30 -> "Baigiasi po $days d."
        else -> "Galioja iki ${car.expiry}"
    }
    val color = when {
        days < 0 -> MaterialTheme.colorScheme.error
        days <= 30 -> androidx.compose.ui.graphics.Color(0xFFB56A00)
        else -> androidx.compose.ui.graphics.Color(0xFF16734A)
    }
    Card {
        Column(Modifier.fillMaxWidth().padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.DirectionsCar, contentDescription = null)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("${car.make} ${car.model}", fontWeight = FontWeight.Bold)
                    Text("${car.plate} • ${car.year}", style = MaterialTheme.typography.bodySmall)
                }
            }
            Spacer(Modifier.height(6.dp))
            Text(status, color = color, style = MaterialTheme.typography.labelMedium)
            if (car.category.isNotBlank()) Text(car.category, style = MaterialTheme.typography.labelSmall)
            if (car.vin.isNotBlank()) Text("VIN: ${car.vin}", style = MaterialTheme.typography.bodySmall)
            if (car.details.isNotBlank()) Text(car.details, style = MaterialTheme.typography.bodySmall)
            if (normalizeCategory(car.category) == "Sunkusis transportas") {
                val tachDays = daysLeft(car.tachographExpiry)
                val tachStatus = when {
                    car.tachographExpiry.isBlank() -> "Tachografo patikra: data nenurodyta"
                    tachDays < 0 -> "Tachografo patikra PASIBAIGĖ"
                    tachDays <= 30 -> "Tachografo patikra baigiasi po $tachDays d."
                    else -> "Tachografo patikra iki ${car.tachographExpiry}"
                }
                Text(tachStatus, color = if (car.tachographExpiry.isNotBlank() && tachDays <= 30) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
            }
            if (car.history.isNotEmpty()) Text("TA istorija: ${car.history.size} įraš.", style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(8.dp))
            Button(onClick = onInspection, modifier = Modifier.fillMaxWidth()) {
                Text("Registruoti techninę apžiūrą")
            }
            if (normalizeCategory(car.category) == "Sunkusis transportas") {
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = onTachograph, modifier = Modifier.weight(1f)) { Text("Tachografas") }
                    OutlinedButton(onClick = onDelete, modifier = Modifier.weight(1f)) { Text("Ištrinti") }
                }
            } else {
                OutlinedButton(onClick = onDelete, modifier = Modifier.fillMaxWidth()) { Text("Ištrinti") }
            }
        }
    }
}

@Composable
fun AddVehicleDialog(onDismiss: () -> Unit, onSave: (Vehicle) -> Unit) {
    var plate by remember { mutableStateOf("") }
    var make by remember { mutableStateOf("") }
    var model by remember { mutableStateOf("") }
    var year by remember { mutableStateOf("") }
    var vin by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Lengvieji automobiliai") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Pridėti automobilį") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(plate, { plate = it.uppercase() }, label = { Text("Valstybinis numeris *") }, singleLine = true)
                OutlinedTextField(make, { make = it }, label = { Text("Markė *") }, singleLine = true)
                OutlinedTextField(model, { model = it }, label = { Text("Modelis") }, singleLine = true)
                OutlinedTextField(year, { year = it }, label = { Text("Pagaminimo metai") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                OutlinedTextField(vin, { vin = it.uppercase() }, label = { Text("VIN numeris") }, singleLine = true)
                Text("Kategorija", fontWeight = FontWeight.SemiBold)
                listOf("Lengvieji automobiliai", "Priekabos", "Sunkusis transportas").forEach { option ->
                    Row(verticalAlignment = Alignment.CenterVertically) { RadioButton(selected = category == option, onClick = { category = option }); Text(option) }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = plate.isNotBlank() && make.isNotBlank(), onClick = {
                onSave(Vehicle(java.util.UUID.randomUUID().toString(), plate.trim(), make.trim(), model.trim(), year.trim(), vin.trim(), "", category = category))
            }) { Text("Išsaugoti") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Atšaukti") } }
    )
}

@Composable
fun TachographDialog(car: Vehicle, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var date by remember { mutableStateOf(car.tachographExpiry.ifBlank { LocalDate.now().plusYears(2).toString() }) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Tachografo patikra – ${car.plate}") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Įrašyk tachografo patikros galiojimo pabaigos datą.")
            OutlinedTextField(date, { date = it }, label = { Text("Galioja iki (YYYY-MM-DD)") }, singleLine = true)
            Text("Pavyzdys: 2027-11-10", style = MaterialTheme.typography.bodySmall)
        }
    }, confirmButton = { TextButton(onClick = { runCatching { LocalDate.parse(date) }.onSuccess { onSave(date) } }) { Text("Išsaugoti") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Atšaukti") } })
}

@Composable
fun InspectionDialog(car: Vehicle, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var mode by remember { mutableStateOf("years") }
    var years by remember { mutableStateOf("1") }
    var date by remember { mutableStateOf(LocalDate.now().plusYears(1).toString()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("TA registravimas – ${car.plate}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Pasirinkite galiojimo nustatymo būdą.")
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(mode == "years", { mode = "years" }); Text("Laikotarpis")
                    Spacer(Modifier.width(8.dp))
                    RadioButton(mode == "date", { mode = "date" }); Text("Tiksli data")
                }
                if (mode == "years") {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(years == "1", { years = "1" }); Text("1 metai")
                        Spacer(Modifier.width(12.dp))
                        RadioButton(years == "2", { years = "2" }); Text("2 metai")
                    }
                    Text("Galios iki: ${LocalDate.now().plusYears(years.toLong())}")
                } else {
                    OutlinedTextField(date, { date = it }, label = { Text("Galiojimo data (YYYY-MM-DD)") }, singleLine = true)
                    Text("Pavyzdys: 2027-11-09")
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val expiry = if (mode == "years") LocalDate.now().plusYears(years.toLong()).toString() else date
                runCatching { LocalDate.parse(expiry) }.onSuccess { onSave(expiry) }
            }) { Text("Išsaugoti TA") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Atšaukti") } }
    )
}

fun daysLeft(date: String): Long {
    if (date.isBlank()) return Long.MAX_VALUE
    return runCatching { ChronoUnit.DAYS.between(LocalDate.now(), LocalDate.parse(date)) }.getOrDefault(Long.MAX_VALUE)
}

fun createNotificationChannel(context: Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        val sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        val channel = NotificationChannel(
            "ta_reminders_sound_v2", "AutoKontrolė – TA priminimai", NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Priminimai apie artėjančią techninės apžiūros pabaigą"
            setSound(sound, android.media.AudioAttributes.Builder()
                .setUsage(android.media.AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build())
            enableVibration(true)
        }
        context.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }
}

class ReminderWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        val context = applicationContext
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val remind15 = prefs.getBoolean(KEY_REMIND_15, true)
        val remind7 = prefs.getBoolean(KEY_REMIND_7, true)
        val sent = prefs.getStringSet(KEY_SENT_REMINDERS, emptySet())?.toMutableSet() ?: mutableSetOf()
        val due15 = mutableListOf<String>()
        val due7 = mutableListOf<String>()

        loadVehicles(context).forEach { car ->
            val days = daysLeft(car.expiry)
            if (days in 8..15 && remind15) {
                val key = "${car.id}|${car.expiry}|15"
                if (sent.add(key)) due15.add(car.plate)
            }
            if (days in 0..7 && remind7) {
                val key = "${car.id}|${car.expiry}|7"
                if (sent.add(key)) due7.add(car.plate)
            }
        }
        prefs.edit().putStringSet(KEY_SENT_REMINDERS, sent).apply()

        val permitted = Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        if (permitted) {
            if (due15.isNotEmpty()) sendTaNotification(context, 1500, "TA baigsis po 15 dienų", due15)
            if (due7.isNotEmpty()) sendTaNotification(context, 700, "TA baigsis po 7 dienų", due7)
        }
        return Result.success()
    }
}

private fun sendTaNotification(context: Context, id: Int, title: String, plates: List<String>) {
    val message = "Reikia pasirūpinti technine apžiūra: ${plates.joinToString(", ")}."
    val notification = NotificationCompat.Builder(context, "ta_reminders_sound_v2")
        .setSmallIcon(android.R.drawable.ic_dialog_info)
        .setContentTitle("AutoKontrolė – $title")
        .setContentText(message)
        .setStyle(NotificationCompat.BigTextStyle().bigText(message))
        .setPriority(NotificationCompat.PRIORITY_HIGH)
        .setDefaults(NotificationCompat.DEFAULT_SOUND or NotificationCompat.DEFAULT_VIBRATE)
        .setAutoCancel(true)
        .build()
    val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    manager.notify(id, notification)
}

fun scheduleDailyReminder(context: Context) {
    val request = PeriodicWorkRequestBuilder<ReminderWorker>(24, TimeUnit.HOURS).build()
    WorkManager.getInstance(context).enqueueUniquePeriodicWork(
        "daily_ta_reminder", ExistingPeriodicWorkPolicy.UPDATE, request
    )
}
