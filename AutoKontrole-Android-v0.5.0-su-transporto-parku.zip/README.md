# AutoKontrolė – vieno naudotojo Android versija

Ši versija skirta vienam žmogui ir vienam Android įrenginiui. Nėra darbuotojų paskyrų, prisijungimo ar bendros internetinės duomenų bazės.

## Funkcijos
- Automobilių pridėjimas: numeris, markė, modelis, metai, VIN.
- TA registravimas: 1 metai, 2 metai arba tiksli galiojimo pabaigos data.
- TA galiojimo būsenos: galioja, baigiasi per 30 dienų, pasibaigusi.
- TA įrašų istorijos skaičiavimas ir rodymas.
- Vietinis duomenų saugojimas telefone.
- Kasdienis fono patikrinimas ir pranešimas apie artėjančią (per 30 d.) arba pasibaigusią TA.

## Paleidimas
1. Atverkite katalogą Android Studio.
2. Palaukite, kol Gradle sinchronizacija baigsis.
3. Prijunkite Android telefoną arba paleiskite emuliatorių.
4. Spauskite Run.

## Svarbu
- Duomenys saugomi tik šiame telefone. Pašalinus programėlę arba išvalius jos duomenis, jie gali būti prarasti. Prieš realų naudojimą rekomenduojama pridėti eksportą / atsarginę kopiją.
- Android 13 ir naujesnėje versijoje reikia leisti pranešimus.
- Fono priminimai vykdomi apytiksliai kas 24 valandas; Android gali atidėti vykdymą dėl baterijos optimizavimo.
- „1 arba 2 metai“ yra patogus skaičiavimo pasirinkimas, bet tikrą TA galiojimo pabaigos datą reikia patikrinti TA dokumente. Patikimiausia įvesti oficialią datą.

## APK kūrimas tik telefonu (GitHub Actions)
Šiame projekte yra `.github/workflows/build-apk.yml` failas. Įkėlus visą projekto turinį į GitHub saugyklą, atverkite **Actions** → **Build AutoKontrole APK** → **Run workflow**. Kai veiksmas baigsis žalia varnele, atverkite vykdymą ir atsisiųskite `AutoKontrole-debug-apk` iš **Artifacts**. Išarchyvuokite ZIP ir telefone atidarykite `app-debug.apk`.
Debug APK yra bandomasis diegimo paketas, ne Play Store leidimas. Įdiekite tik savo sukurtą ir patikrintą paketą.


## TA priminimai 0.3.0
- Programėlės viršutinėje juostoje yra pranešimų (varpelio) nustatymai.
- Galima atskirai įjungti / išjungti priminimą prieš 15 ir prieš 7 dienas.
- Priminimai tikrinami kasdien fone; kiekvienam automobiliui ir konkrečiai TA galiojimo datai tas pats priminimas siunčiamas tik vieną kartą.
- Pranešimai naudoja Android numatytąjį pranešimo garsą ir vibraciją. Android nustatymuose turi būti leidžiami AutoKontrolė pranešimai ir jų garsas.
- WorkManager vykdymo laikas yra apytikslis ir gali būti atidėtas dėl Android baterijos taupymo režimo.


## Versija 0.4.0 – TA sąrašo filtrai
- **VISI** rodo visus automobilius.
- **ARTĖJA** rodo automobilius, kurių TA baigiasi per artimiausias 30 dienų (įskaitant šiandien).
- **PASIBAIGĖ** rodo automobilius, kurių TA galiojimo data jau praėjusi.
- Paieška pagal numerį, markę, modelį ir VIN veikia kartu su pasirinktu filtru.


## Versija 0.5.0 – transporto parko importas
- Pirmą kartą paleidus šią versiją automatiškai įkeliamos 27 transporto priemonės iš naudotojo pateikto PDF „Transporto Mašinų Automobilių Sąrašas 2026-06“.
- Įkeliami valstybiniai numeriai, markės, modeliai, pagaminimo metai (kai pateikti), VIN ir papildomi PDF duomenys: SDK, spalva, dokumento numeris, registracijos data, EURO klasė ir pastabos.
- PDF faile techninės apžiūros pabaigos datos neužpildytos, todėl TA data paliekama tuščia; ją reikia suvesti pagal oficialius dokumentus.
- Importas atliekamas tik vieną kartą ir nedubliuoja jau esančių numerių.
