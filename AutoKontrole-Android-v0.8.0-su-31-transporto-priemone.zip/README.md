# AutoKontrolė 0.8.0

Šioje versijoje į pradinį programėlės sąrašą įkelta 31 transporto priemonė pagal naudotojo pateiktą PDF „Transporto Mašinų Automobilių Sąrašas 2026-11-11“.

- 19 sunkiojo transporto priemonių ir priekabų
- 12 lengvųjų automobilių
- Įkelti valstybiniai numeriai, markės, modeliai, VIN, TA pabaigos datos ir papildomos pastabos
- Duomenys įkeliami pirmą kartą paleidus programėlę ir išsaugomi telefone

Svarbu: PDF lentelėje kai kurių gamybos metų ar registracijos duomenų nėra, todėl jie palikti tušti, o ne spėjami.
