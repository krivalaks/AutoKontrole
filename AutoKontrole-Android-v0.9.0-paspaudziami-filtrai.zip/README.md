# AutoKontrolė 0.9.0

Atnaujinimas: pagrindinės suvestinės kortelės VISI, ARTĖJA ir PASIBAIGĖ dabar yra paspaudžiami filtrai. Atskiros eilutės „Rodyti automobilius“ su filtrais pašalintos. Kategorijų filtrai ir paieška palikti.

Projektas kuriamas Android APK per GitHub Actions. Programėlės duomenys saugomi telefone.
